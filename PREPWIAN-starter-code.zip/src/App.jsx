import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity, Atom, BarChart3, Bell, BookOpen, BrainCircuit, CalendarDays,
  Check, ChevronDown, ChevronRight, CircleHelp, Clock3, Command, Compass,
  Dna, Flame, FlaskConical, GraduationCap, LayoutDashboard, ListChecks,
  Menu, Moon, Play, Plus, Search, Settings2, ShieldCheck, Sparkles, Sun,
  Target, Timer, Trophy, X, Zap
} from 'lucide-react';

const initialTasks = [
  { id: 1, title: 'Revise — Laws of Motion', subject: 'Physics', time: '45 min', done: true },
  { id: 2, title: 'Chemical Bonding: practice set', subject: 'Chemistry', time: '60 min', done: false },
  { id: 3, title: 'Limits & Derivatives', subject: 'Mathematics', time: '50 min', done: false },
  { id: 4, title: 'Cell: The Unit of Life', subject: 'Biology', time: '35 min', done: false },
];
const initialQuestions = [
  { id: 1, subject: 'Physics', topic: 'Mechanics', level: 'Medium', question: 'A body starts from rest and moves with constant acceleration. Which quantity is directly proportional to the square of time?', options: ['Velocity', 'Displacement', 'Acceleration', 'Momentum'], answer: 1, explanation: 'For constant acceleration from rest, s = ½at², so displacement is proportional to t².' },
  { id: 2, subject: 'Chemistry', topic: 'Atomic Structure', level: 'Easy', question: 'The maximum number of electrons in a shell with principal quantum number n = 3 is:', options: ['8', '18', '32', '9'], answer: 1, explanation: 'The maximum number of electrons in a shell is 2n². For n = 3, this is 18.' },
  { id: 3, subject: 'Mathematics', topic: 'Functions', level: 'Medium', question: 'If f(x) = 2x + 3, then f(f(1)) equals:', options: ['8', '10', '13', '15'], answer: 2, explanation: 'f(1) = 5, then f(5) = 13.' },
  { id: 4, subject: 'Biology', topic: 'Cell Biology', level: 'Easy', question: 'Which organelle is primarily associated with ATP production in eukaryotic cells?', options: ['Golgi apparatus', 'Lysosome', 'Mitochondrion', 'Ribosome'], answer: 2, explanation: 'Mitochondria are the major site of aerobic respiration and ATP generation in eukaryotic cells.' },
];
const nav = [
  ['Overview', LayoutDashboard], ['Study Planner', CalendarDays], ['Practice Arena', Target],
  ['Study Library', BookOpen], ['Focus Room', Timer], ['Analytics', BarChart3]
];
const subjects = [
  { name: 'Physics', icon: Atom, color: 'violet', progress: 68, detail: 'Mechanics · Electrodynamics' },
  { name: 'Chemistry', icon: FlaskConical, color: 'mint', progress: 52, detail: 'Physical · Organic · Inorganic' },
  { name: 'Mathematics', icon: Activity, color: 'blue', progress: 74, detail: 'Algebra · Calculus · Geometry' },
  { name: 'Biology', icon: Dna, color: 'rose', progress: 41, detail: 'Botany · Zoology · Genetics' },
];

function readStore(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}

function App() {
  const [page, setPage] = useState('Overview');
  const [dark, setDark] = useState(readStore('prepwian-theme', true));
  const [mobileNav, setMobileNav] = useState(false);
  const [tasks, setTasks] = useState(() => readStore('prepwian-tasks', initialTasks));
  const [query, setQuery] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [newTask, setNewTask] = useState('');
  const [newSubject, setNewSubject] = useState('Physics');
  const [toast, setToast] = useState('');
  const [focusSeconds, setFocusSeconds] = useState(25 * 60);
  const [focusRunning, setFocusRunning] = useState(false);
  const [focusMode, setFocusMode] = useState('Focus');
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);
  const [answers, setAnswers] = useState(() => readStore('prepwian-answers', []));
  const [exam, setExam] = useState('JEE Main');
  const [showProfile, setShowProfile] = useState(false);

  useEffect(() => { localStorage.setItem('prepwian-theme', JSON.stringify(dark)); }, [dark]);
  useEffect(() => { localStorage.setItem('prepwian-tasks', JSON.stringify(tasks)); }, [tasks]);
  useEffect(() => { localStorage.setItem('prepwian-answers', JSON.stringify(answers)); }, [answers]);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(''), 2600);
    return () => clearTimeout(id);
  }, [toast]);
  useEffect(() => {
    if (!focusRunning) return;
    const id = setInterval(() => setFocusSeconds(s => {
      if (s <= 1) { setFocusRunning(false); setToast('Focus session complete. Take a short break!'); return 0; }
      return s - 1;
    }), 1000);
    return () => clearInterval(id);
  }, [focusRunning]);

  const doneCount = tasks.filter(t => t.done).length;
  const currentQuestion = initialQuestions[questionIndex % initialQuestions.length];
  const filteredTasks = useMemo(() => tasks.filter(t => `${t.title} ${t.subject}`.toLowerCase().includes(query.toLowerCase())), [tasks, query]);
  const accuracy = answers.length ? Math.round(answers.filter(a => a.correct).length / answers.length * 100) : 0;

  function toggleTask(id) { setTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t)); }
  function addTask(e) {
    e.preventDefault();
    if (!newTask.trim()) return;
    setTasks(prev => [...prev, { id: Date.now(), title: newTask.trim(), subject: newSubject, time: '30 min', done: false }]);
    setNewTask(''); setShowAdd(false); setToast('Task added to your study plan.');
  }
  function go(next) { setPage(next); setMobileNav(false); }
  function resetFocus(minutes) { setFocusSeconds(minutes * 60); setFocusRunning(false); }
  function submitAnswer() {
    if (selected === null) return;
    setRevealed(true);
    setAnswers(prev => [...prev, { questionId: currentQuestion.id, correct: selected === currentQuestion.answer, subject: currentQuestion.subject }]);
  }
  function nextQuestion() {
    setQuestionIndex(i => (i + 1) % initialQuestions.length);
    setSelected(null); setRevealed(false);
  }

  return <div className={dark ? 'app dark' : 'app light'}>
    <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
      <div className="brand" onClick={() => go('Overview')} role="button" tabIndex="0">
        <div className="brand-mark"><Atom size={23}/></div>
        <div><div className="brand-name">PREPWIAN<span>®</span></div><div className="brand-tag">PREPARE BEYOND LIMITS</div></div>
        <button className="icon-btn mobile-close" onClick={e => {e.stopPropagation();setMobileNav(false)}} aria-label="Close menu"><X size={18}/></button>
      </div>
      <div className="workspace-label">YOUR WORKSPACE</div>
      <nav className="main-nav">
        {nav.map(([name, Icon]) => <button key={name} className={`nav-item ${page === name ? 'active' : ''}`} onClick={() => go(name)}>
          <Icon size={18}/><span>{name}</span>{name === 'Practice Arena' && <span className="nav-pill">NEW</span>}
        </button>)}
      </nav>
      <div className="workspace-label exam-label">EXAM MODE</div>
      <div className="exam-select">
        <GraduationCap size={18}/>
        <select value={exam} onChange={e => {setExam(e.target.value);setToast(`${e.target.value} mode selected.`)}} aria-label="Select exam">
          <option>JEE Main</option><option>JEE Advanced</option><option>NEET UG</option>
        </select><ChevronDown size={15}/>
      </div>
      <div className="sidebar-spacer"/>
      <div className="upgrade-card">
        <div className="upgrade-orb"><Sparkles size={18}/></div>
        <div className="upgrade-title">Your next level awaits.</div>
        <p>Build a consistent study streak, one session at a time.</p>
        <button onClick={() => go('Analytics')} className="upgrade-btn">View your progress <ChevronRight size={15}/></button>
      </div>
      <button className="nav-item settings-link" onClick={() => setToast('Settings are coming in a future release.')}><Settings2 size={18}/><span>Settings</span></button>
      <div className="sidebar-user">
        <div className="avatar">PW</div><div className="user-info"><strong>Prep Warrior</strong><span>Student workspace</span></div><button className="icon-btn" aria-label="Profile options" onClick={() => setShowProfile(v => !v)}><ChevronDown size={16}/></button>
        {showProfile && <div className="profile-pop"><strong>Student profile</strong><p>Your progress is saved on this device.</p><button onClick={() => {setShowProfile(false);setToast('Profile settings will be available soon.')}}>Manage profile</button></div>}
      </div>
    </aside>

    {mobileNav && <button className="mobile-scrim" onClick={() => setMobileNav(false)} aria-label="Close navigation"/>}
    <main className="main">
      <header className="topbar">
        <div className="top-left"><button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu size={20}/></button><div className="breadcrumb">Workspace <ChevronRight size={14}/> <strong>{page}</strong></div></div>
        <div className="top-actions">
          <div className="search-box"><Search size={16}/><input placeholder="Search your workspace..." value={query} onChange={e => setQuery(e.target.value)} /><kbd>⌘ K</kbd></div>
          <button className="icon-btn theme-toggle" onClick={() => setDark(v => !v)} aria-label="Toggle theme">{dark ? <Sun size={18}/> : <Moon size={18}/>}</button>
          <button className="icon-btn notification-btn" onClick={() => setToast('You’re all caught up. No new notifications.')} aria-label="Notifications"><Bell size={18}/><i/></button>
          <button className="top-avatar" onClick={() => setShowProfile(v => !v)}>PW</button>
        </div>
      </header>

      <div className="page-content">
        {page === 'Overview' && <Overview {...{tasks, doneCount, go, accuracy, exam, setToast, setShowAdd}} />}
        {page === 'Study Planner' && <Planner {...{filteredTasks, tasks, toggleTask, showAdd, setShowAdd, newTask, setNewTask, newSubject, setNewSubject, addTask, query}} />}
        {page === 'Practice Arena' && <Practice {...{currentQuestion, questionIndex, selected, setSelected, revealed, submitAnswer, nextQuestion, answers, accuracy, exam}} />}
        {page === 'Study Library' && <Library setToast={setToast} query={query} />}
        {page === 'Focus Room' && <Focus {...{focusSeconds, focusRunning, setFocusRunning, focusMode, setFocusMode, resetFocus}} />}
        {page === 'Analytics' && <Analytics {...{tasks, doneCount, answers, accuracy}} />}
      </div>
      <footer className="footer"><span>© 2026 PREPWIAN</span><span><span className="status-dot"/> All progress saved locally <span className="footer-divider">·</span> Built for your next breakthrough</span></footer>
    </main>
    {toast && <div className="toast"><Check size={17}/>{toast}<button onClick={() => setToast('')} aria-label="Dismiss"><X size={14}/></button></div>}
  </div>;
}

function PageHeading({eyebrow, title, subtitle, action}) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>;
}
function Overview({tasks, doneCount, go, accuracy, exam, setToast, setShowAdd}) {
  const completion = tasks.length ? Math.round(doneCount / tasks.length * 100) : 0;
  return <>
    <div className="welcome-banner">
      <div className="welcome-copy"><div className="welcome-chip"><Sparkles size={13}/> YOUR LEARNING UNIVERSE</div><h1>Make today<br/> <span>count.</span></h1><p>Small, consistent steps. Extraordinary results.<br/>Your next breakthrough starts right here.</p><div className="welcome-actions"><button className="primary-btn" onClick={() => go('Study Planner')}>Continue learning <ChevronRight size={17}/></button><button className="ghost-btn" onClick={() => go('Practice Arena')}><Play size={15}/> Quick practice</button></div></div>
      <div className="orbit-art" aria-hidden="true"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/><div className="planet planet-main"><Atom size={50}/></div><div className="planet planet-small"><Dna size={21}/></div><div className="planet planet-dot"/></div>
      <div className="banner-bottom"><span><span className="live-dot"/> YOUR {exam.toUpperCase()} JOURNEY</span><span>Consistency beats intensity.</span></div>
    </div>
    <div className="section-heading"><div><h2>Your momentum</h2><p>A quick look at how you're moving forward.</p></div><button className="text-btn" onClick={() => go('Analytics')}>Full analytics <ChevronRight size={15}/></button></div>
    <div className="stats-grid">
      <StatCard icon={ListChecks} label="Tasks completed" value={`${doneCount}/${tasks.length}`} note={`${completion}% of your plan`} color="purple" progress={completion}/>
      <StatCard icon={Flame} label="Study streak" value="3 days" note="Keep the rhythm going" color="orange" progress={30}/>
      <StatCard icon={Target} label="Practice accuracy" value={`${accuracy}%`} note={accuracy ? 'Based on answered questions' : 'Start a practice session'} color="green" progress={accuracy}/>
      <StatCard icon={Clock3} label="Focus target" value="4.0 hrs" note="Daily goal · editable soon" color="blue" progress={62}/>
    </div>
    <div className="dashboard-grid">
      <section className="panel task-panel"><div className="panel-head"><div><h3>Today's mission</h3><p>Your next steps, clearly laid out.</p></div><button className="round-action" onClick={() => setShowAdd(true)} aria-label="Add task"><Plus size={18}/></button></div>
        <div className="task-list">{tasks.slice(0,4).map(t => <div className={`task-row ${t.done ? 'task-done' : ''}`} key={t.id}><span className={`task-check ${t.done ? 'checked' : ''}`}>{t.done && <Check size={13}/>}</span><div className="task-copy"><strong>{t.title}</strong><span>{t.subject} <i/> {t.time}</span></div><ChevronRight size={16} className="task-chevron"/></div>)}</div>
        <button className="panel-link" onClick={() => go('Study Planner')}>Open full planner <ChevronRight size={15}/></button>
      </section>
      <section className="panel subjects-panel"><div className="panel-head"><div><h3>Subject constellation</h3><p>Your syllabus, one topic at a time.</p></div><button className="icon-btn" onClick={() => go('Analytics')} aria-label="Subject analytics"><BarChart3 size={17}/></button></div>
        <div className="subject-list">{subjects.map(s => <div className="subject-row" key={s.name}><div className={`subject-icon ${s.color}`}><s.icon size={18}/></div><div className="subject-info"><div className="subject-title"><strong>{s.name}</strong><span>{s.progress}%</span></div><div className="progress-track"><div className={`progress-fill ${s.color}`} style={{width:`${s.progress}%`}}/></div><span className="subject-detail">{s.detail}</span></div></div>)}</div>
        <button className="panel-link" onClick={() => go('Study Library')}>Explore study library <ChevronRight size={15}/></button>
      </section>
    </div>
    <section className="panel quick-tools"><div className="panel-head"><div><h3>Jump back in</h3><p>Tools for your next focused session.</p></div><span className="tiny-label">QUICK ACCESS</span></div><div className="tool-grid">
      <QuickTool icon={CalendarDays} title="Plan your day" desc="Shape your next study block" onClick={() => go('Study Planner')} tone="purple"/>
      <QuickTool icon={BrainCircuit} title="Practice questions" desc="Sharpen concepts with questions" onClick={() => go('Practice Arena')} tone="blue"/>
      <QuickTool icon={Timer} title="Focus room" desc="Protect your attention" onClick={() => go('Focus Room')} tone="green"/>
      <QuickTool icon={BookOpen} title="Study resources" desc="Find notes and revision aids" onClick={() => go('Study Library')} tone="orange"/>
    </div></section>
  </>;
}
function StatCard({icon:Icon,label,value,note,color,progress}) {
  return <div className="stat-card"><div className="stat-top"><span className={`stat-icon ${color}`}><Icon size={18}/></span><span className="stat-more">↗</span></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div><div className="stat-track"><div className={`stat-progress ${color}`} style={{width:`${Math.min(100,progress)}%`}}/></div></div>;
}
function QuickTool({icon:Icon,title,desc,onClick,tone}) {
  return <button className="quick-tool" onClick={onClick}><span className={`quick-tool-icon ${tone}`}><Icon size={19}/></span><span className="quick-tool-copy"><strong>{title}</strong><small>{desc}</small></span><ChevronRight size={16} className="quick-arrow"/></button>;
}
function Planner({filteredTasks,tasks,toggleTask,showAdd,setShowAdd,newTask,setNewTask,newSubject,setNewSubject,addTask,query}) {
  const completed = tasks.filter(t=>t.done).length;
  return <>
    <PageHeading eyebrow="YOUR ROUTINE, REIMAGINED" title="Study planner" subtitle="Turn big goals into manageable, daily actions." action={<button className="primary-btn" onClick={()=>setShowAdd(true)}><Plus size={16}/> Add task</button>}/>
    <div className="planner-summary"><div><span className="summary-label">TODAY'S COMPLETION</span><strong>{completed} <small>/ {tasks.length} tasks</small></strong><div className="wide-progress"><span style={{width:`${tasks.length?completed/tasks.length*100:0}%`}}/></div></div><div className="summary-side"><CalendarDays size={21}/><span>Consistency over perfection.</span></div></div>
    {showAdd && <form className="panel add-task-form" onSubmit={addTask}><div className="form-heading"><h3>Add a study task</h3><button type="button" className="icon-btn" onClick={()=>setShowAdd(false)} aria-label="Close"><X size={17}/></button></div><input autoFocus value={newTask} onChange={e=>setNewTask(e.target.value)} placeholder="e.g. Revise electrostatics notes" required/><div className="form-row"><select value={newSubject} onChange={e=>setNewSubject(e.target.value)}><option>Physics</option><option>Chemistry</option><option>Mathematics</option><option>Biology</option><option>General</option></select><button className="primary-btn" type="submit">Save task <Check size={15}/></button></div></form>}
    <section className="panel planner-list"><div className="panel-head"><div><h3>Study checklist</h3><p>{query ? `Search results for “${query}”` : 'Check off each step as you complete it.'}</p></div><span className="count-badge">{filteredTasks.length} tasks</span></div>
      {filteredTasks.length ? filteredTasks.map(t=><button key={t.id} className={`planner-task ${t.done?'task-done':''}`} onClick={()=>toggleTask(t.id)}><span className={`task-check ${t.done?'checked':''}`}>{t.done&&<Check size={13}/>}</span><span className="planner-task-text"><strong>{t.title}</strong><small>{t.subject} · {t.time}</small></span><span className={`task-status ${t.done?'complete':''}`}>{t.done?'Completed':'To do'}</span></button>) : <div className="empty-state"><Search size={25}/><strong>No tasks found</strong><p>Try another search or add a new task.</p></div>}
    </section>
    <div className="notice-card"><ShieldCheck size={20}/><div><strong>Your plan stays yours.</strong><p>This starter version saves tasks in this browser. Cloud sync and multi-device access need a backend integration.</p></div></div>
  </>;
}
function Practice({currentQuestion,questionIndex,selected,setSelected,revealed,submitAnswer,nextQuestion,answers,accuracy,exam}) {
  return <>
    <PageHeading eyebrow="TRAIN YOUR THINKING" title="Practice arena" subtitle={`A question at a time. Build confidence for ${exam}.`} action={<div className="practice-score"><Target size={16}/><span>{answers.length} attempted</span></div>}/>
    <div className="practice-layout"><section className="panel question-panel"><div className="question-meta"><span className="subject-tag">{currentQuestion.subject}</span><span>{currentQuestion.topic}</span><span className="difficulty">{currentQuestion.level}</span><span className="question-count">QUESTION {questionIndex+1} / {initialQuestions.length}</span></div><div className="question-progress"><span style={{width:`${(questionIndex+1)/initialQuestions.length*100}%`}}/></div><h2>{currentQuestion.question}</h2><div className="options-list">{currentQuestion.options.map((opt,i)=><button key={opt} disabled={revealed} onClick={()=>setSelected(i)} className={`answer-option ${selected===i?'selected':''} ${revealed&&i===currentQuestion.answer?'correct':''} ${revealed&&selected===i&&i!==currentQuestion.answer?'incorrect':''}`}><span className="option-letter">{String.fromCharCode(65+i)}</span><span>{opt}</span>{revealed&&i===currentQuestion.answer&&<Check size={17}/>}</button>)}</div>{revealed&&<div className={`explanation ${selected===currentQuestion.answer?'good':'try-again'}`}><strong>{selected===currentQuestion.answer?'Correct — nicely done!':'Not quite. Learn from it.'}</strong><p>{currentQuestion.explanation}</p></div>}<div className="question-footer"><span><CircleHelp size={15}/> Practice mode · Explanations included</span>{revealed?<button className="primary-btn" onClick={nextQuestion}>Next question <ChevronRight size={16}/></button>:<button className="primary-btn" disabled={selected===null} onClick={submitAnswer}>Check answer <Check size={16}/></button>}</div></section>
      <aside className="practice-side"><div className="panel accuracy-panel"><div className="mini-icon purple"><BarChart3 size={19}/></div><span className="side-label">YOUR ACCURACY</span><strong>{accuracy}%</strong><p>{answers.length ? `${answers.filter(a=>a.correct).length} correct out of ${answers.length} attempts` : 'Your results will appear here.'}</p><div className="wide-progress"><span style={{width:`${accuracy}%`}}/></div></div><div className="panel practice-tip"><Sparkles size={19}/><h3>Learning tip</h3><p>Try to solve the problem yourself before checking the explanation. Understanding the “why” is where improvement happens.</p></div></aside></div>
    <div className="notice-card"><BookOpen size={20}/><div><strong>Starter question set</strong><p>This repository includes sample questions to demonstrate the experience, not a complete or officially verified JEE/NEET question bank.</p></div></div>
  </>;
}
function Library({setToast,query}) {
  const [filter,setFilter] = useState('All');
  const resources = [
    {title:'Physics formula vault',desc:'Core formulas and quick revision cards',type:'Formula sheets',subject:'Physics',icon:Atom,color:'purple'},
    {title:'Chemistry reaction map',desc:'Organised reaction pathways for revision',type:'Revision notes',subject:'Chemistry',icon:FlaskConical,color:'green'},
    {title:'Mathematics concept sheets',desc:'Definitions, identities and key methods',type:'Revision notes',subject:'Mathematics',icon:Activity,color:'blue'},
    {title:'Biology NCERT checklist',desc:'Chapter-by-chapter reading tracker',type:'Chapter guides',subject:'Biology',icon:Dna,color:'pink'},
    {title:'PYQ practice organiser',desc:'Plan previous-year-question sessions',type:'Practice sets',subject:'All subjects',icon:Target,color:'orange'},
    {title:'Weekly revision template',desc:'A reusable structure for spaced revision',type:'Templates',subject:'All subjects',icon:CalendarDays,color:'purple'},
  ];
  const visible = resources.filter(r=>(filter==='All'||r.type===filter)&&`${r.title} ${r.desc} ${r.subject}`.toLowerCase().includes(query.toLowerCase()));
  return <>
    <PageHeading eyebrow="YOUR KNOWLEDGE BASE" title="Study library" subtitle="A home for revision resources, formula sheets and practice material." action={<button className="ghost-btn" onClick={()=>setToast('Connect a storage provider to upload and manage real files.')}><Plus size={16}/> Add resource</button>}/>
    <div className="library-banner"><div className="library-banner-icon"><BookOpen size={27}/></div><div><strong>Your next concept is one page away.</strong><p>Organise resources by subject, format and exam. Upload support can be connected in a future backend phase.</p></div><Sparkles size={22} className="library-spark"/></div>
    <div className="filter-tabs">{['All','Formula sheets','Revision notes','Chapter guides','Practice sets','Templates'].map(f=><button key={f} className={filter===f?'selected':''} onClick={()=>setFilter(f)}>{f}</button>)}</div>
    <div className="resource-grid">{visible.map(r=><article className="panel resource-card" key={r.title}><div className={`resource-icon ${r.color}`}><r.icon size={22}/></div><div className="resource-type">{r.type}</div><h3>{r.title}</h3><p>{r.desc}</p><div className="resource-bottom"><span>{r.subject}</span><button onClick={()=>setToast(`${r.title}: add your own resource content to make this card useful.`)}>Open resource <ChevronRight size={15}/></button></div></article>)}</div>
    <div className="notice-card"><ShieldCheck size={20}/><div><strong>Respect content ownership.</strong><p>Only upload material you created or are authorised to distribute. Keep copyrighted coaching PDFs private unless you have permission.</p></div></div>
  </>;
}
function Focus({focusSeconds,focusRunning,setFocusRunning,focusMode,setFocusMode,resetFocus}) {
  const mins = Math.floor(focusSeconds/60).toString().padStart(2,'0');
  const secs = (focusSeconds%60).toString().padStart(2,'0');
  const total = focusMode==='Focus'?25*60:focusMode==='Short break'?5*60:15*60;
  const progress = 100-(focusSeconds/total*100);
  return <>
    <PageHeading eyebrow="PROTECT YOUR ATTENTION" title="Focus room" subtitle="One task. One session. No need to do everything at once."/>
    <div className="focus-layout"><section className="panel focus-main"><div className="focus-status"><span className="live-dot"/>{focusRunning?'SESSION IN PROGRESS':'READY WHEN YOU ARE'}</div><div className="focus-tabs">{['Focus','Short break','Long break'].map((m,i)=><button key={m} className={focusMode===m?'active':''} onClick={()=>{setFocusMode(m);resetFocus(i===0?25:i===1?5:15)}}>{m}</button>)}</div><div className="timer-wrap"><svg viewBox="0 0 280 280" className="timer-ring"><circle cx="140" cy="140" r="124" className="timer-track"/><circle cx="140" cy="140" r="124" className="timer-progress" style={{strokeDashoffset:779-(progress/100*779)}}/></svg><div className="timer-display"><strong>{mins}:{secs}</strong><span>{focusMode.toUpperCase()}</span></div></div><div className="focus-controls"><button className="primary-btn focus-start" onClick={()=>setFocusRunning(v=>!v)}>{focusRunning?'Pause session':<><Play size={16}/> Start session</>}</button><button className="icon-btn reset-btn" onClick={()=>resetFocus(focusMode==='Focus'?25:focusMode==='Short break'?5:15)} aria-label="Reset timer"><Activity size={18}/></button></div><p className="focus-caption">You don't need perfect motivation. Just begin.</p></section><aside className="focus-aside"><div className="panel focus-note"><div className="mini-icon green"><Zap size={18}/></div><h3>Make focus easier</h3><ul><li>Choose one clear task.</li><li>Keep distractions out of reach.</li><li>Take breaks without guilt.</li><li>Record what you learned.</li></ul></div><div className="panel focus-note muted-note"><Flame size={20}/><h3>Build your rhythm</h3><p>Consistency grows when your plan fits real life. Start with one session and adjust from there.</p></div></aside></div>
  </>;
}
function Analytics({tasks,doneCount,answers,accuracy}) {
  const bars = [35,52,42,74,58,88,doneCount?Math.min(100,doneCount/tasks.length*100):0];
  const days = ['M','T','W','T','F','S','S'];
  const subjectsCount = ['Physics','Chemistry','Mathematics','Biology'].map(s=>({name:s,count:answers.filter(a=>a.subject===s).length,correct:answers.filter(a=>a.subject===s&&a.correct).length}));
  return <>
    <PageHeading eyebrow="MEASURE WHAT MATTERS" title="Your analytics" subtitle="Use the signals to adjust your study plan, not to judge yourself."/>
    <div className="stats-grid analytics-stats"><StatCard icon={ListChecks} label="Tasks completed" value={`${doneCount}/${tasks.length}`} note="From your current checklist" color="purple" progress={tasks.length?doneCount/tasks.length*100:0}/><StatCard icon={Target} label="Answer accuracy" value={`${accuracy}%`} note={`${answers.length} recorded attempts`} color="green" progress={accuracy}/><StatCard icon={Clock3} label="Focus target" value="4.0 hrs" note="Example daily target" color="blue" progress={62}/><StatCard icon={Flame} label="Current streak" value="3 days" note="Sample display" color="orange" progress={30}/></div>
    <div className="analytics-grid"><section className="panel activity-panel"><div className="panel-head"><div><h3>Weekly activity</h3><p>Illustrative activity until real session tracking is connected.</p></div><span className="count-badge">7 days</span></div><div className="bar-chart">{bars.map((v,i)=><div className="bar-column" key={i}><div className="bar-value" style={{height:`${v}%`}}/><span>{days[i]}</span></div>)}</div></section><section className="panel breakdown-panel"><div className="panel-head"><div><h3>Subject breakdown</h3><p>Question attempts by subject.</p></div></div>{subjectsCount.map(s=><div className="breakdown-row" key={s.name}><div><strong>{s.name}</strong><span>{s.count} attempts</span></div><div className="breakdown-track"><span style={{width:`${answers.length?s.count/answers.length*100:0}%`}}/></div></div>)}</section></div>
    <div className="notice-card"><Activity size={20}/><div><strong>Honest data, better decisions.</strong><p>Some dashboard values are sample placeholders. Production analytics should use verified session data and secure user accounts before they are presented as real results.</p></div></div>
  </>;
}

export default App;
