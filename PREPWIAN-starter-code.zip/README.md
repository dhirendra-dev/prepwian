# PREPWIAN

**Prepare Beyond Limits** — a futuristic learning workspace starter for JEE Main, JEE Advanced and NEET UG.

## Included in this starter

- Responsive dashboard with dark/light themes
- Exam-mode selector for JEE Main, JEE Advanced and NEET UG
- Study checklist with add, search and completion tracking
- Practice Arena with sample MCQs, answer feedback and explanations
- Study Library resource catalogue with filters
- Focus Room with configurable Pomodoro-style timer
- Analytics dashboard for task and sample question progress
- Local browser persistence for tasks, theme and practice attempts
- Responsive mobile navigation and reduced-motion support

## Run locally

Requirements: Node.js 20+ recommended.

```bash
npm install
npm run dev
```

Create a production build:

```bash
npm run build
npm run preview
```

## Deployment

This is a Vite + React application and can be deployed to Vercel. Import the repository, use `npm run build` as the build command and `dist` as the output directory.

## Important production work still required

This repository is a functional front-end starter, not a finished production exam platform.

Before launching publicly, add and test:
- Supabase Auth, database schema, row-level security policies and user-owned data
- Secure server-side authorization for admin functions
- Cloud storage and permission checks for notes and uploaded files
- Verified and properly licensed question banks, answer keys and explanations
- Real mock-test engine with timing, navigation, negative marking settings, submission and review
- Server-backed analytics, reminders and cross-device sync
- Error monitoring, accessibility testing, automated tests, rate limits and privacy/terms pages
- Secrets stored in deployment environment variables; never commit service-role keys or private API keys

Dashboard streaks, focus target and some analytics visuals are illustrative placeholders. Sample questions are for demonstrating the UI only and are not a complete or officially verified JEE/NEET question bank. The current localStorage persistence is device/browser-specific and is not a secure user database.

## Suggested next milestones

1. **Foundation:** connect Supabase Auth, profile setup and secure user-owned tables.
2. **Exam engine:** build configurable CBT tests, timer, mark-for-review, negative marking and results review.
3. **Planner 2.0:** lecture planner imports, backlog prioritisation, recurring schedule and reminders.
4. **Resource centre:** uploads, topic tags, saved resources and rights-aware sharing.
5. **Production readiness:** tests, audit logging, security review, accessibility and monitoring.

## Tech stack

- React 18
- Vite 6
- Lucide React icons
- Recharts dependency available for future analytics charts
- CSS design tokens with dark and light themes
